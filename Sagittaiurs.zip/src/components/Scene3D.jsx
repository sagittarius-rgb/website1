import { Canvas, useFrame } from "@react-three/fiber";
import { Float, MeshDistortMaterial, Sparkles, OrbitControls } from "@react-three/drei";
import { useRef } from "react";

function Arrow({ reduced }) {
  const g = useRef();
  useFrame((_, dt) => { if (!reduced && g.current) g.current.rotation.y += dt * 0.5; });
  const mat = <MeshDistortMaterial color="#E88A42" distort={reduced ? 0 : 0.25} speed={2} roughness={0.25} metalness={0.4} />;
  return (
    <group ref={g} rotation={[0, 0, Math.PI / 4]}>
      <mesh position={[0, -0.2, 0]}><cylinderGeometry args={[0.18, 0.18, 2.6, 32]} />{mat}</mesh>
      <mesh position={[0, 1.4, 0]}><coneGeometry args={[0.55, 0.9, 32]} />{mat}</mesh>
      <mesh position={[0, -1.1, 0]} rotation={[Math.PI / 2, 0, 0]}><torusGeometry args={[0.7, 0.07, 16, 48]} /><meshStandardMaterial color="#FFD1B3" /></mesh>
    </group>
  );
}

export default function Scene3D() {
  const reduced = typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  return (
    <Canvas dpr={[1, 1.5]} camera={{ position: [0, 0, 5.5], fov: 45 }} aria-label="3D Sagittarius arrow">
      <ambientLight intensity={0.9} />
      <directionalLight position={[4, 4, 5]} intensity={1.6} />
      <Float speed={reduced ? 0 : 2} floatIntensity={1.2}><Arrow reduced={reduced} /></Float>
      {!reduced && <Sparkles count={50} scale={7} size={4} speed={0.5} color="#FFB366" />}
      <OrbitControls enableZoom={false} enablePan={false} />
    </Canvas>
  );
}
