import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ChevronLeft, ChevronRight } from "lucide-react";
import Img from "./Img.jsx";

// Replace with GENUINE testimonials (with permission) before launch.
const T = [
  { q: "Sample text: replace with a real student testimonial.", n: "Student name", r: "Course, College", img: "students" },
  { q: "Sample text: replace with a real business testimonial.", n: "Client name", r: "Company, Role", img: "bba" },
  { q: "Sample text: replace with a real viva-preparation testimonial.", n: "Student name", r: "Course, College", img: "library" },
];

export default function Testimonials() {
  const [i, setI] = useState(0);
  const go = (d) => setI((i + d + T.length) % T.length);
  useEffect(() => { const t = setInterval(() => setI((x) => (x + 1) % T.length), 6000); return () => clearInterval(t); }, []);
  const t = T[i];
  return (
    <section className="py-14" aria-roledescription="carousel" aria-label="Testimonials">
      <h2 className="mb-6 text-3xl font-extrabold">What Our Community Says</h2>
      <div className="relative h-80 overflow-hidden rounded-[28px] shadow-warm">
        <AnimatePresence mode="wait">
          <motion.div key={i} className="absolute inset-0" initial={{ opacity: 0, x: 60 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -60 }} transition={{ duration: 0.5 }}>
            <Img slot={t.img} className="h-full w-full" />
            <div className="absolute inset-0 flex flex-col justify-end bg-gradient-to-t from-ink/80 via-ink/30 to-transparent p-8 text-white">
              <p className="max-w-2xl text-xl font-semibold md:text-2xl">“{t.q}”</p>
              <p className="mt-3 text-sm"><b>{t.n}</b> · {t.r}</p>
            </div>
          </motion.div>
        </AnimatePresence>
        <button aria-label="Previous" onClick={() => go(-1)} className="absolute left-3 top-1/2 rounded-full bg-white/90 p-2 text-ink"><ChevronLeft /></button>
        <button aria-label="Next" onClick={() => go(1)} className="absolute right-3 top-1/2 rounded-full bg-white/90 p-2 text-ink"><ChevronRight /></button>
        <div className="absolute right-4 top-4 flex gap-1">{T.map((_, k) => <span key={k} className={`h-2 w-2 rounded-full ${k === i ? "bg-brand" : "bg-white/70"}`} />)}</div>
      </div>
    </section>
  );
}
