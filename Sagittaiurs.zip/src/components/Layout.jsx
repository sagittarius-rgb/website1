import { Link, NavLink, useLocation } from "react-router-dom";
import { Menu, X, GraduationCap, Briefcase } from "lucide-react";
import { useEffect, useState } from "react";

export const Logo = () => (
  <Link to="/" className="flex shrink-0 items-center gap-2.5" aria-label="Sagittarius home">
    <span className="grid h-11 w-11 place-items-center">
      <img src="/logo.png" alt="" className="h-full w-full object-contain" />
    </span>
    <span className="leading-tight">
      <span className="block text-xl font-extrabold tracking-tight text-ink">Sagittarius</span>
      <span className="hidden text-[10px] font-semibold uppercase tracking-[0.18em] text-accent sm:block">
        Students · Business
      </span>
    </span>
  </Link>
);

const links = [
  ["/", "Home"], ["/students", "Student Projects"], ["/academic", "Academic Services"],
  ["/business", "Business Solutions"], ["/certificate", "Certificates"], ["/about", "About"], ["/contact", "Contact"],
];

export function Navbar() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const { pathname } = useLocation();

  useEffect(() => setOpen(false), [pathname]);
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    const onKey = (e) => e.key === "Escape" && setOpen(false);
    window.addEventListener("keydown", onKey);
    return () => { document.body.style.overflow = ""; window.removeEventListener("keydown", onKey); };
  }, [open]);

  const desktopLink = ({ isActive }) =>
    `whitespace-nowrap rounded-full px-3 py-2 text-sm font-medium transition ${isActive ? "bg-pale text-ink" : "text-ink/75 hover:bg-pale/70 hover:text-ink"}`;
  const mobileLink = ({ isActive }) =>
    `flex items-center justify-between rounded-xl px-4 py-3.5 text-base font-semibold ${isActive ? "bg-pale text-ink" : "text-ink hover:bg-ivory"}`;

  return (
    <header className={`sticky top-0 z-50 border-b transition-shadow ${scrolled ? "border-line bg-cream/95 shadow-warm backdrop-blur" : "border-transparent bg-cream"}`}>
      <nav aria-label="Main" className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-4 px-4 sm:px-6">
        <Logo />

        {/* Desktop (xl and up) */}
        <div className="hidden items-center gap-0.5 xl:flex">
          {links.map(([to, label]) => (
            <NavLink key={to} to={to} end={to === "/"} className={desktopLink}>{label}</NavLink>
          ))}
        </div>
        <div className="hidden shrink-0 items-center gap-2 xl:flex">
          <Link to="/login/student" className="btn-ghost !px-4 !py-2 whitespace-nowrap text-sm">Student Login</Link>
          <Link to="/login/business" className="btn-primary !px-4 !py-2 whitespace-nowrap text-sm">Business Login</Link>
        </div>

        {/* Mobile / tablet toggle */}
        <button
          className="grid h-10 w-10 place-items-center rounded-full border border-line bg-white text-ink xl:hidden"
          aria-label={open ? "Close menu" : "Open menu"} aria-expanded={open} aria-controls="mobile-menu"
          onClick={() => setOpen(!open)}>
          {open ? <X size={20} /> : <Menu size={20} />}
        </button>
      </nav>

      {/* Mobile / tablet panel */}
      {open && (
        <div id="mobile-menu" className="fixed inset-x-0 bottom-0 top-16 overflow-y-auto border-t border-line bg-cream px-4 pb-10 pt-4 xl:hidden">
          <div className="mx-auto flex max-w-xl flex-col gap-1">
            {links.map(([to, label]) => (
              <NavLink key={to} to={to} end={to === "/"} className={mobileLink}>{label}</NavLink>
            ))}
          </div>
          <div className="mx-auto mt-6 grid max-w-xl gap-3 sm:grid-cols-2">
            <Link to="/login/student" className="btn-ghost gap-2"><GraduationCap size={18} /> Student Login</Link>
            <Link to="/login/business" className="btn-primary gap-2"><Briefcase size={18} /> Business Login</Link>
          </div>
        </div>
      )}
    </header>
  );
}

export const Footer = () => (
  <footer className="mt-16 border-t border-line bg-ivory px-5 py-10 text-center text-sm">
    <div className="mb-3 flex justify-center"><Logo /></div>
    Empowering Students. Innovating Businesses.
    <p className="mt-2">Student Services · Business Solutions · Academic Projects · Privacy Policy · Terms and Conditions</p>
    <p className="mt-2">© {new Date().getFullYear()} Sagittarius</p>
  </footer>
);