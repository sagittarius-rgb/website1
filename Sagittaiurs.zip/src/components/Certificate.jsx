// Usage: <Certificate />  or  <Certificate data={{ name, title, id, date }} />
const sample = { name: "Student Name", title: "Online Examination System", id: "SAG-2026-0001", date: "02 November 2026" };

export default function Certificate({ data = sample }) {
  const d = { ...sample, ...data };
  return (
    <div className="mx-auto w-full max-w-3xl">
      <div className="aspect-[1.414/1] rounded-xl bg-[#FFFDF7] p-2 shadow-xl sm:p-3">
        <div className="flex h-full flex-col items-center justify-between rounded-lg border-2 border-[#FFB366] px-3 py-3 text-center sm:px-8 sm:py-8">
          <div>
            <p className="text-sm font-extrabold tracking-wide text-[#29251F] sm:text-xl">Sagittarius</p>
            <p className="text-[6px] tracking-[0.25em] text-[#766B60] sm:text-[10px]">EMPOWERING STUDENTS. INNOVATING BUSINESSES.</p>
          </div>
          <div>
            <h3 className="font-serif text-base tracking-wide text-[#29251F] sm:text-4xl">Certificate of Completion</h3>
            <div className="mx-auto my-1 h-0.5 w-12 bg-[#E88A42] sm:my-4 sm:w-24" />
            <p className="text-[8px] text-[#766B60] sm:text-sm">This is to certify that</p>
            <p className="my-0.5 font-serif text-lg italic text-[#E88A42] sm:my-2 sm:text-4xl">{d.name}</p>
            <p className="text-[8px] text-[#766B60] sm:text-sm">
              has successfully completed the project <b className="text-[#29251F]">“{d.title}”</b>
            </p>
          </div>
          <div className="flex w-full items-end justify-between text-[7px] text-[#766B60] sm:text-xs">
            <div className="text-left">
              <p>ID: <b className="text-[#29251F]">{d.id}</b></p>
              <p>Issued: <b className="text-[#29251F]">{d.date}</b></p>
            </div>
            <div className="text-center">
              <p className="font-serif text-xs italic text-[#29251F] sm:text-lg">A. Signature</p>
              <div className="h-px w-16 bg-[#29251F]/40 sm:w-28" />
              <p>Authorized Signatory</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
