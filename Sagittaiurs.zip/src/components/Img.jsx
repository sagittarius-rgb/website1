import { useState } from "react";
import { IMAGES } from "../images.js";

const q = (b, w) => `${b}?auto=format&fit=crop&q=70&w=${w}`;

export default function Img({ slot, className = "", priority = false }) {
  const meta = IMAGES[slot];
  const tries = [meta?.local, meta?.base].filter(Boolean);
  const [i, setI] = useState(0);
  if (!meta || i >= tries.length)
    return <div role="img" aria-label={meta?.alt || slot} className={`bg-gradient-to-br from-pale to-peach ${className}`} />;
  const cur = tries[i], remote = cur === meta.base;
  return (
    <img src={remote ? q(cur, 1000) : cur}
      srcSet={remote ? `${q(cur, 500)} 500w, ${q(cur, 1000)} 1000w, ${q(cur, 1600)} 1600w` : undefined}
      sizes="(max-width: 768px) 100vw, 50vw"
      style={{ objectPosition: meta.pos }}
      alt={meta.alt} onError={() => setI(i + 1)}
      loading={priority ? "eager" : "lazy"} decoding="async" className={`object-cover ${className}`} />
  );
}
