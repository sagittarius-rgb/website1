import { lazy, Suspense, useState } from "react";
import { Link, useParams, useSearchParams } from "react-router-dom";
import { motion } from "framer-motion";
import { projects, academic, business, courses } from "./data.js";
import Tilt from "./components/Tilt.jsx";
import Certificate from "./components/Certificate.jsx";
import Img from "./components/Img.jsx";
const Scene3D = lazy(() => import("./components/Scene3D.jsx"));

const Grid = ({ children }) => <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">{children}</div>;
const refId = (p) => `${p}-${Date.now().toString(36).toUpperCase()}`;

export function Students() {
  const [sp] = useSearchParams(); const [q, setQ] = useState(""), [c, setC] = useState(sp.get("course") || ""), [d, setD] = useState(""), [ref, setRef] = useState("");
  const list = projects.filter((p) => (!c || p.c === c) && (!d || p.d === d) && (p.t + p.s).toLowerCase().includes(q.toLowerCase()));
  return (
    <>
      <h1 className="text-3xl font-extrabold sm:text-4xl">Student Project Explorer</h1>
      <div className="my-6 grid gap-3 sm:grid-cols-3">
        <input className="field !mb-0" placeholder="Search projects" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search" />
        <select className="field !mb-0" value={c} onChange={(e) => setC(e.target.value)} aria-label="Course"><option value="">All courses</option>{courses.map(([x]) => <option key={x}>{x}</option>)}</select>
        <select className="field !mb-0" value={d} onChange={(e) => setD(e.target.value)} aria-label="Difficulty"><option value="">All levels</option>{["Beginner", "Intermediate", "Advanced"].map((x) => <option key={x}>{x}</option>)}</select>
      </div>
      <Grid>{list.map((p) => (
        <Tilt key={p.t} className="!p-0 overflow-hidden"><Img slot={p.c.toLowerCase().replace(/ /g, "-")} className="h-36 w-full" /><div className="p-5"><h3 className="font-bold">{p.t}</h3><div className="my-2"><span className="tag">{p.c}</span><span className="tag">{p.d}</span><span className="tag">{p.s}</span></div></div></Tilt>))}</Grid>
      <h2 className="mb-3 mt-12 text-2xl font-extrabold">Request a Project</h2>
      <form className="card max-w-xl" onSubmit={(e) => { e.preventDefault(); setRef(refId("SAG-STU")); }}>
        <input required className="field" placeholder="Your name" /><input required className="field" placeholder="Project title" />
        <button className="btn-primary">Submit Request</button>{ref && <p role="status" className="mt-3 font-semibold text-ink">Received. Reference ID: {ref}</p>}
      </form>
    </>
  );
}

const Services = ({ title, items }) => (<><h1 className="mb-6 text-4xl font-extrabold">{title}</h1><Grid>{items.map(([t, d]) => <Tilt key={t}><h3 className="font-bold">{t}</h3><p className="mt-2">{d}</p></Tilt>)}</Grid></>);
export const Academic = () => <Services title="Academic Services" items={academic} />;

export function Business() {
  const [ref, setRef] = useState("");
  return (
    <>
      <Services title="Business Solutions" items={business} />
      <h2 className="mb-3 mt-12 text-2xl font-extrabold">Business Request</h2>
      <form className="card max-w-xl" onSubmit={(e) => { e.preventDefault(); setRef(refId("SAG-BIZ")); }}>
        <input required className="field" placeholder="Company name" /><input required type="email" className="field" placeholder="Business email" />
        <select className="field">{business.map(([t]) => <option key={t}>{t}</option>)}</select>
        <button className="btn-primary">Submit Request</button>{ref && <p role="status" className="mt-3 font-semibold text-ink">Received. Reference ID: {ref}</p>}
      </form>
    </>
  );
}

export function About() {
  const [id, setId] = useState(""), [res, setRes] = useState("");
  return (
    <>
      <h1 className="text-4xl font-extrabold">About Sagittarius</h1>
      <p className="my-4 max-w-2xl">Sagittarius connects college students, universities, startups and businesses through academic projects, technical learning and real-world technology solutions.</p>
      <h2 className="mb-3 mt-8 text-2xl font-extrabold">Verify a Certificate</h2>
      <form className="card max-w-xl" onSubmit={(e) => { e.preventDefault(); setRes(!id.trim() ? "" : id.trim().toUpperCase() === "SAG-2026-0001" ? "ok" : "none"); }}>
        <input className="field" placeholder="SAG-2026-0001" value={id} onChange={(e) => setId(e.target.value)} aria-label="Certificate ID" />
        <button className="btn-primary">Verify</button>{res === "none" && <p role="status" className="mt-3">Not found in this demo. Try SAG-2026-0001, then connect GET /api/certificates/:id for real data.</p>}
      </form>
      {res === "ok" && <div role="status" className="mt-6"><p className="mb-3 font-semibold text-ink">✔ Certificate verified (demo)</p><Certificate /></div>}
    </>
  );
}

export function CertificatePage() {
  return (
    <>
      <h1 className="mb-2 text-3xl font-extrabold sm:text-4xl">Sample Certificate</h1>
      <p className="mb-6 max-w-2xl">Certificates are issued after a project is completed and verified. Each has a unique ID that can be checked on the About page.</p>
      <Certificate />
      <div className="mt-6 flex justify-center gap-3"><button onClick={() => window.print()} className="btn-primary">Print / Save as PDF</button><Link to="/about" className="btn-ghost">Verify a Certificate</Link></div>
    </>
  );
}

export function Contact() {
  const [ok, setOk] = useState(false);
  return (
    <>
      <h1 className="mb-6 text-4xl font-extrabold">Contact Us</h1>
      <form className="card max-w-xl" onSubmit={(e) => { e.preventDefault(); setOk(true); }}>
        <input required className="field" placeholder="Name" /><input required type="email" className="field" placeholder="Email" /><textarea required className="field" rows="4" placeholder="Message" />
        <button className="btn-primary">Send</button>{ok && <p role="status" className="mt-3 text-ink">Thanks, we will get back to you.</p>}
      </form>
    </>
  );
}

export function Login() {
  const { role } = useParams(); const student = role !== "business"; const [msg, setMsg] = useState("");
  return (
    <div className="grid overflow-hidden rounded-3xl border border-line md:grid-cols-2">
      <div className="flex min-h-[280px] flex-col justify-end bg-gradient-to-br from-peach to-brand p-8 text-ink">
        <h2 className="text-3xl font-extrabold">Welcome to Sagittarius</h2><p>{student ? "Learn, build, present and achieve." : "Transform your business with technology."}</p></div>
      <form className="bg-white p-8" onSubmit={(e) => { e.preventDefault(); setMsg("Connect this form to your auth API (POST /api/auth/login)."); }}>
        <h3 className="mb-4 text-xl font-bold">{student ? "Student" : "Business"} Login</h3>
        <input required type="email" className="field" placeholder="Email" /><input required type="password" className="field" placeholder="Password" />
        <div className="flex gap-3"><button className="btn-primary">Login</button><Link to="/contact" className="btn-ghost">Create account</Link></div>
        {msg && <p role="status" className="mt-3 text-sm">{msg}</p>}
      </form>
    </div>
  );
}
