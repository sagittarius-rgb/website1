// Slots try: local file in /public/images -> verified free Unsplash photo (Unsplash License) -> peach gradient.
// `pos` is the CSS object-position, so one photo can show a different crop in different places.
const un = (id) => `https://images.unsplash.com/photo-${id}`;
const STUDENTS = un("1758270705290-62b6294dd044"); // students around a laptop, lecture hall (Vitaly Gariev)
const LIBRARY  = un("1753613648242-6b6c5b88e4d1"); // student coding in a library (Hasnain Ayaz)
const MICRO    = un("1518152006812-edab29b069ac"); // microscope (Ousa Chea)
const DESK     = un("1762427355235-dd22e5cb010c"); // calculator, binders, notebook (Cht Gsml)
const CALC     = un("1707779491435-000c45820db2"); // calculator beside a laptop (Mehdi Mirzaie)

const s = (file, base, alt, pos = "center") => ({ local: `/images/${file}`, base, alt, pos });
export const IMAGES = {
  // hero + sections
  hero:      s("hero.jpg", STUDENTS, "Students gathered around a laptop in a lecture hall"),
  about:     s("about.jpg", LIBRARY, "Student working on a laptop in a library"),
  students:  s("students.jpg", STUDENTS, "University students working together on laptops"),
  library:   s("library.jpg", LIBRARY, "University library study space"),
  business:  s("business.jpg", CALC, "Calculator and laptop on a business desk", "left"),
  // courses (one different photo each)
  bca:       s("bca.jpg", STUDENTS, "BCA students collaborating on laptops"),
  "bsc-it":  s("bsc-it.jpg", LIBRARY, "BSc IT student coding on a laptop"),
  bsc:       s("bsc.jpg", MICRO, "Microscope for BSc science practicals"),
  bba:       s("bba.jpg", CALC, "Business calculations for BBA projects", "left"),
  "b.com":   s("bcom.jpg", DESK, "Accounting desk with calculator and binders for B.Com"),
  "data-analytics": s("data-analytics.jpg", CALC, "Laptop and calculator for data analytics", "right"),
  // what we offer
  "offer-projects":  s("offer-projects.jpg", STUDENTS, "Students building an academic project", "left"),
  "offer-reports":   s("offer-reports.jpg", DESK, "Notebook and binders for project reports", "right"),
  "offer-viva":      s("offer-viva.jpg", LIBRARY, "Student preparing for viva and presentation", "right"),
  "offer-business":  s("offer-business.jpg", CALC, "Business solutions on a laptop", "center"),
  "offer-analytics": s("offer-analytics.jpg", CALC, "Data analytics work", "right"),
};
