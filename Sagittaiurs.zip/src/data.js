export const courses = [
  ["BCA", "Bachelor of Computer Applications"],
  ["BSc IT", "BSc Information Technology"],
  ["BSc", "Bachelor of Science"],
  ["BBA", "Business Administration"],
  ["B.Com", "Bachelor of Commerce"],
  ["Data Analytics", "Data Analytics projects"],
];
export const projects = [
  { t: "Student Management System", c: "BCA", d: "Beginner", s: "React, Node, MongoDB" },
  { t: "Library Management System", c: "BCA", d: "Beginner", s: "Java, SQL" },
  { t: "Online Examination System", c: "BCA", d: "Intermediate", s: "React, Express, PostgreSQL" },
  { t: "Network Monitoring Tool", c: "BSc IT", d: "Intermediate", s: "Python, SNMP" },
  { t: "Online Quiz Application", c: "BSc IT", d: "Beginner", s: "HTML, CSS, JavaScript" },
  { t: "Portfolio Website", c: "BSc IT", d: "Beginner", s: "React, Tailwind CSS" },
  { t: "Weather Data Analysis", c: "BSc", d: "Beginner", s: "Python, Excel" },
  { t: "Water Quality Study", c: "BSc", d: "Intermediate", s: "Lab data, Statistics" },
  { t: "Digital Marketing Analysis", c: "BBA", d: "Beginner", s: "Survey, Excel" },
  { t: "Employee Satisfaction Study", c: "BBA", d: "Beginner", s: "SPSS, Excel" },
  { t: "Financial Statement Analysis", c: "BBA", d: "Intermediate", s: "Excel" },
  { t: "GST Study", c: "B.Com", d: "Beginner", s: "Research" },
  { t: "Digital Payment Analysis", c: "B.Com", d: "Intermediate", s: "Excel, Survey" },
  { t: "Cost Accounting Case Study", c: "B.Com", d: "Beginner", s: "Excel" },
  { t: "Sales Dashboard", c: "Data Analytics", d: "Intermediate", s: "Power BI, SQL" },
  { t: "Customer Churn Analysis", c: "Data Analytics", d: "Advanced", s: "Python, ML" },
  { t: "HR Analytics Dashboard", c: "Data Analytics", d: "Intermediate", s: "Tableau, Excel" },
  { t: "AI Chatbot", c: "Data Analytics", d: "Advanced", s: "Python, NLP" },
  { t: "E-Commerce Application", c: "BCA", d: "Advanced", s: "MERN" },
];
export const academic = [
  ["Project Documentation", "Synopsis, literature review, architecture, UML, testing, references."],
  ["Report Making", "BCA, BSc, BSc IT, BBA, B.Com, Data Analytics and research reports."],
  ["PPT Preparation", "Project, seminar, research and business presentations."],
  ["Viva Preparation", "Technical, methodology and database questions with practice answers."],
];
export const business = [
  ["Website Development", "Business, e-commerce, portfolio and React web apps."],
  ["Software Development", "CRM, inventory, automation, API and AI integration."],
  ["Data Analytics", "Power BI, Tableau, Python and SQL analytics."],
  ["Business Reports", "Market, financial, HR and performance reports."],
  ["Digital Marketing", "SEO, social, content and campaign analysis."],
];
export const tech = "React,Tailwind CSS,HTML,CSS,JavaScript,Node.js,Express.js,Angular,Bootstrap,Python,Django,.NET,Machine Learning,Power BI,Tableau,SQL".split(",");
