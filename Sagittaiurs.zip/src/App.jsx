import { Routes, Route, useLocation } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";
import { Navbar, Footer } from "./components/Layout.jsx";
import { Home } from "./home.jsx";
import { CertificatePage, Students, Academic, Business, About, Contact, Login } from "./pages.jsx";

export default function App() {
  const loc = useLocation();
  return (
    <>
      <Navbar />
      <AnimatePresence mode="wait">
        <motion.main key={loc.pathname} className="mx-auto max-w-6xl px-5 pt-6"
          initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
          <Routes location={loc}>
            <Route path="/" element={<Home />} />
            <Route path="/students" element={<Students />} />
            <Route path="/academic" element={<Academic />} />
            <Route path="/business" element={<Business />} />
            <Route path="/certificate" element={<CertificatePage />} />
            <Route path="/about" element={<About />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/login/:role" element={<Login />} />
            <Route path="*" element={<Home />} />
          </Routes>
        </motion.main>
      </AnimatePresence>
      <Footer />
    </>
  );
}
