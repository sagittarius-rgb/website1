import { lazy, Suspense } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { tech, courses } from "./data.js";
import Tilt from "./components/Tilt.jsx";
import Img from "./components/Img.jsx";
import Certificate from "./components/Certificate.jsx";
import { Award } from "lucide-react";
import Testimonials from "./components/Testimonials.jsx";
const Scene3D = lazy(() => import("./components/Scene3D.jsx"));

const offers = [
  ["offer-projects", "Academic Projects", "BCA, BSc, BSc IT, BBA, B.Com and Data Analytics projects with guidelines."],
  ["offer-reports", "Reports and Documentation", "Synopsis, project reports, UML and testing documentation."],
  ["offer-viva", "PPT and Viva Preparation", "Presentation decks and viva practice with sample questions."],
  ["offer-business", "Business Solutions", "Websites, software and custom technology for businesses."],
  ["offer-analytics", "Data Analytics", "Power BI, Tableau, Python and SQL dashboards and reports."],
];

export function Home() {
  return (
    <>
      <section className="grid items-center gap-8 rounded-[28px] bg-gradient-to-br from-cream via-ivory to-pale p-5 sm:p-8 md:grid-cols-2 md:p-12">
        <div>
          <h1 className="text-3xl font-extrabold leading-tight sm:text-4xl md:text-6xl">Turn Your Ideas Into Innovative Projects</h1>
          <p className="mt-4">Your ultimate destination for academic projects, professional development, technology solutions, and business innovation.</p>
          <div className="mt-6 flex flex-wrap gap-3">
            <Link to="/students" className="btn-primary">Explore Student Projects</Link>
            <Link to="/business" className="btn-ghost">Explore Business Solutions</Link>
          </div>
        </div>
        <div className="relative h-80 md:h-96">
          <Img slot="hero" priority className="h-full w-full rounded-3xl shadow-warm" />
          <div className="absolute inset-0 rounded-3xl bg-gradient-to-t from-peach/40 to-transparent" />
          <div className="absolute bottom-2 right-2 h-32 w-32 sm:h-40 sm:w-40 md:-bottom-4 md:-right-2 rounded-3xl bg-white/70 shadow-warm backdrop-blur md:h-48 md:w-48"><Suspense fallback={null}><Scene3D /></Suspense></div>
          <motion.span animate={{ y: [0, -8, 0] }} transition={{ repeat: Infinity, duration: 4 }} className="absolute left-4 top-4 rounded-2xl bg-white px-3 py-1 text-xs font-semibold text-ink shadow">React · Node</motion.span>
        </div>
      </section>

      <section className="grid items-center gap-8 py-16 md:grid-cols-2">
        <Img slot="about" className="h-80 w-full rounded-3xl shadow-warm" />
        <div>
          <h2 className="mb-3 text-3xl font-extrabold">Who We Are</h2>
          <p>Sagittarius is an educational technology and business solutions platform. We connect college students, universities, startups and businesses through academic projects, technical learning and real-world technology solutions.</p>
          <p className="mt-3">We help students understand, customise and present their own work, and help businesses turn ideas into working software, analytics and reports.</p>
          <Link to="/about" className="btn-primary mt-5">Learn More</Link>
        </div>
      </section>

      <section className="pb-14">
        <h2 className="mb-6 text-3xl font-extrabold">What We Offer</h2>
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {offers.map(([s, t, d]) => (
            <Tilt key={t} className="!p-0 overflow-hidden"><Img slot={s} className="h-40 w-full" /><div className="p-5"><h3 className="font-bold">{t}</h3><p className="mt-1 text-sm">{d}</p></div></Tilt>
          ))}
          <Link to="/certificate"><Tilt className="!p-0 h-full overflow-hidden"><div className="grid h-40 place-items-center bg-gradient-to-br from-peach to-brand"><Award className="h-14 w-14 text-white" /></div><div className="p-5"><h3 className="font-bold">Verified Certificates</h3><p className="mt-1 text-sm">Earn a digital certificate on completion and verify it online.</p></div></Tilt></Link>
        </div>
      </section>

      <section className="pb-14">
        <h2 className="mb-6 text-3xl font-extrabold">Courses We Support</h2>
        <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
          {courses.map(([c, full]) => (
            <Link key={c} to={`/students?course=${encodeURIComponent(c)}`} className="card !p-0 overflow-hidden transition hover:-translate-y-1">
              <Img slot={c.toLowerCase().replace(/ /g, "-")} className="h-24 w-full sm:h-32" />
              <div className="p-3"><h3 className="font-bold">{c}</h3><p className="text-xs">{full}</p></div>
            </Link>
          ))}
        </div>
      </section>

      <section className="grid items-center gap-8 pb-14 md:grid-cols-2">
        <div><h2 className="mb-3 text-3xl font-extrabold">Earn a Verified Certificate</h2>
          <p>Complete your project and receive a Sagittarius certificate with a unique ID that anyone can verify online.</p>
          <Link to="/certificate" className="btn-primary mt-5">View Sample Certificate</Link></div>
        <Certificate />
      </section>

      <Testimonials />

      <section className="pb-14"><h2 className="mb-4 text-3xl font-extrabold">Technologies</h2>
        {tech.map((t) => <span key={t} className="tag !px-4 !py-2 !text-sm">{t}</span>)}</section>

      <section className="rounded-[28px] bg-gradient-to-br from-ivory to-pale p-10 text-center">
        <h2 className="text-3xl font-extrabold">Your Next Big Idea Starts Here</h2><p className="my-2">Build your future with Sagittarius.</p>
        <div className="mt-4 flex justify-center gap-3"><Link to="/login/student" className="btn-primary">Join as a Student</Link><Link to="/contact" className="btn-ghost">Partner With Us</Link></div>
      </section>
    </>
  );
}
